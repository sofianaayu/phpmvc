<div class="container mt-5">
    <link rel="shortcut icon" href="img/smkn2.png" />
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title"><?= $data['guru']['nama']; ?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?= $data['guru']['mata_pelajaran']; ?></h6>
            <a href=" <?= BASE_URL; ?>/guru" class="btn btn-primary">kembali</a>
        </div>
    </div>
</div>