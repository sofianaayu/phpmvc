<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">

</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Ekstrakurikuler</h3>
            <h4>KEGIATAN PENGEMBANGAN DIRI / EKSTRAKURIKULER</h4>
            <br>
            <p>
                Ekstrakurikuler bertujuan memberikan kesempatan kepada peserta didik untuk mengembangkan dan
                <br>
                mengekspresikan diri sesuai dengan kebutuhan, minat, bakat dan kreatifitas dalam bentuk kegiatan
                <br>
                ekstrakurikuler dan pelayanan konseling.
            </p>
            <p>
                1. Pramuka
                <br>
                2. Tujuan
            </p>
            <p>
                Tujuan pelaksanaan kegiatan ekstrakurikuler pendidikan kepramukaan ialah:
            </p>
            <p>
                1. Meningkatnya kemampuan kognitif, afektif, dan psikomotor peserta didik.
                <br>
                2. Berkembangnya bakat dan minat peserta didik dalam upaya pembinaan pribadi menuju pembinaan manusia seutuhnya.
                <br>
                3. Terbudayakannya sikap dan perilaku peduli terhadap lingkungan sesuai dengan program yang dilatihkan kepada siswa
                <br>
                4. Terbangunnya sikap siswa melalui kegiatan praktis dan empiris sehingga siswa memperoleh pengalaman belajar untuk berkembangnya sikapnya yang sesuai dengan nilai-nilai yang terdapat dalam pelaksanaan pelatihan pramuka.
                <br>
                5. Tercapainya kompetensi yang dapat diukur sebagai dasar penentukan evaluasi kegiatan pelatihan.
                <br>
                6. Strategi pelaksanaan
            </p>
            <p>
                Strategi pelaksanaan kegiatan kepramukaan menggunakan pendekatan standar pengelolaan, yaitu meliputi
                <br>
                kegiatan merencanakan, melaksanakan, memonitor, dan mengevaluasi kegiatan yang disertai dengan tindak
                <br>
                lanjut perbaikan.
            </p>
            <p>

                Ketua Pembina wajib memenuhi dokumen perencanaan, pelaksanaan, dan evaluasi serta bertanggu jawab
                <br>
                kepada kepala sekolah. Pelaksanaan kegiatan kepramukaan meliputi tiga model strategi, yaitu;
            </p>
        </div>
    </div>
</body>

</html>