<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>halaman<?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container mt-3">
        <div class="row">
            <div class="col-4">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Data Siswa
                </button>
            </div>

            <div class="container mt-5">
                <div class="row">
                    <div class="col-8">
                        <h3>DATA SISWA</h3>
                        <ul class="list-group">
                            <?php foreach ($data['siswa'] as $siswa) : ?>
                                <li class="list-group-item list-group-item d-flex justify-content-between align-items-center">
                                    <?= $siswa['nama']; ?>
                                    <div>
                                        <a href="<?= BASE_URL; ?>/siswa/hapus/<?= $siswa['id'] ?>" class="btn btn-danger float-right" onclick="returnconfirm('yakin?');">hapus</a>
                                        <a href="<?= BASE_URL; ?>/siswa/ubah/ <?= $siswa['id'] ?>" class="btn btn-success" data-toggle="modal" data-target="#formModal" data-id="<?= $siswa['id']; ?>">edit</a>
                                        <a href="<?= BASE_URL; ?>/siswa/detail/<?= $siswa['id'] ?>" class="btn btn-primary">detail</a>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tambah Data Siswa</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= BASE_URL; ?>/siswa/tambah" method="post">
                                    <input type="hidden" name="id" id="id">
                                    <div class="form-group">
                                        <label for="nama">Nama</label>
                                        <input type="text" class="form-control" id="nama" name="nama">
                                    </div>
                                    <div class="form-group">
                                        <label for="jenis_kelamin">Jenis Kelamin</label>
                                        <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                            <option value="laki-laki">Laki - laki</option>
                                            <option value="perempuan">Perempuan</opt ion>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat">Alamat</label>
                                        <input type="text" class="form-control" id="alamat" name="alamat">
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Tambah Data</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <?php Flasher::flash(); ?>
                    </div>
                </div>


</body>

</html>