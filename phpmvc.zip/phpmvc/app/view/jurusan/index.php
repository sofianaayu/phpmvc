<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">

</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h2>Kompetensi Keahlian</h2>
            <p>
            <h4>LOGO KOMPETENSI KEAHLIAN SMKN NEGERI 2 TRENGGALEK</h4>
            </p>
        </div>
    </div>
    <br>
    <div class="container">
        <img src="img/rpl.jpg" class="rounded float-left" width="360px">
        <img src="img/akl.jpg" class="rounded float-right" width="360px">
        <img src="img/dpib.jpg" class="rounded float-left" width="360px">
    </div>
    <br>
    <div class="container">
        <img src="img/kgsp.jpeg" class="rounded float-left" width="360px">
        <img src="img/tb.jpg" class="rounded float-right" width="360px">
        <img src="img/tptu.jpg" class="rounded float-left" width="360px">
    </div>
</body>

</html>