<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SMKN 2 TRENGGALEK<?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <!-- <div class="container">
        <img src="img/smkn2.png" width="7%" height="5%" alt="gambar" style="float:left; margin:0 10px 0px 0;" />
        <h3>Sekolah Menengah Kejuruan Negeri 2 Trenggalek</h3>
        <h5>Website Resmi SMKN2 Trenggalek</h5>
    </div> -->
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Sambutan Kepala SMKN 2 TRENGGALEK</h3>
            <!-- <p class="lead">Perkenalkan, saya <?= $data['nama']; ?></p> -->
            <br>
            <p>
                <img src="img/kepsek.jpg" width="40%" height="70%" alt="gambar" style="float:left; margin:0 20px 4px 0;" />
                Bismillahirohmannirrohim
            <p>
                Assalamualaikum Warahmatullah Wabarakatuh
            </p>
            <p>
                Selamat datang di website resmi SMKN 2 Trenggalek.
                <br>
                Saya berharap Website ini dapat dijadikan wahana
                <br>
                interaksi yang positif baik antar civitas akademika
                <br>
                maupun masyarakat pada umumnya sehingga dapat
                <br>
                menjalin silaturahmi yang erat disegala unsur. Mari kita
                <br>
                bekerja dan berkarya dengan mengharap ridho sang
                <br>
                Kuasa dan keikhlasan yang tulus, dijiwai demi anak
                <br>
                bangsa.
            </p>
            <p>
                Terima kasih semoga Allah 'Azza Wa Jalla menyertai
                doa kita semua……aamiin
            </p>
            </p>
        </div>
    </div>

    <!-- <div class="container">
        <div class="jumbroton mt-4">
            <h2>Sejarah</h2>
            <p>SMK Negeri 2 Trenggalek berdiri tanggal 21 Mei 2004.
                <br>
                Menurut SK Bupati Trenggalek no. 275 tahun 2004
                <br>
                tentang pendidikan SMKN 2 Trenggalek, SMKN 2
                <br>
                Trenggalek awalnya bernama SMK Kecil di SMPN 5
                <br>
                Trenggalek. Gedung yang dimiliki dulu adalah Bekas
                <br>
                SDN...
            </p>
        </div>
    </div> -->

    <div class="text-right">
        <div class="container">
            <div class="jumbroton mt-4">
                <img src="img/smkn2.png" width="20%" height="60%" alt="gambar" style="float:left; margin:0 20px 4px 0;" />
                <h2>Visi dan Misi</h2>
                <p>Visi Terwujudnya sekolah unggul yang peduli dan
                    <br>
                    berbudaya lingkungan Misi Meningkatkan
                    <br>
                    penghayatan dan pengamalan terhadap ajaran agama
                    <br>
                    yang dianut. Menciptakan suasana akademik yang
                    <br>
                    kondusif. Menyiapkan sumber daya pendidikan yang
                    <br>
                    berkualitas dan bermanfaat bagi pengembangan
                    <br>
                    potensi peserta didik. Menyelenggarakan proses
                    <br>
                    pembelajaran...
                </p>
            </div>
        </div>
    </div>
</body>

</html>