<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Halaman <?= $data['judul']; ?></title>
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>About Me</h3>
            <!-- <p class="lead">Perkenalkan, saya <?= $data['nama']; ?></p> -->
            <br>
            <p>
                <img src="img/sofiana.jpeg" width="30%" height="50%" alt="gambar" style="float:left; margin:0 20px 4px 0;" />

            <p>
                Nama : Sofiana Ayu Wulandari
                <br>
                Jurusan : RPL
                <br>
                Temp.Tgl.Lahir : Trenggalek, 2005-09-15
                <br>
                Alamat : Dusun Donosari RT 11 RW 4 Ds. Sidomulyo Kec. Pule
            </p>
        </div>
    </div>
</body>

</html>