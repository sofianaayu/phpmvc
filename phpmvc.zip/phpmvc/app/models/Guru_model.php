<?php
class guru_Model
{
    private $table = 'guru';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }
    public function getAllguru()
    {
        $this->db->query("SELECT * FROM " . $this->table);
        return $this->db->resultAll();
    }
    public function getguruById($id)
    {
        $this->db->query("SELECT * FROM " . $this->table . ' WHERE id=:id');
        $this->db->bind('id', $id);
        return $this->db->resultSingle();
    }
    public function tambahData($data)
    {
        $query = " INSERT INTO guru VALUES ('', :nama, :mata_pelajaran) ";
        $this->db->query($query);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('mata_pelajaran', $data['mata_pelajaran']);
        $this->db->execute();
        return $this->db->rowCount();
    }
    public function hapusDataguru($id)
    {
        $query = "DELETE FROM guru WHERE id = :id";

        $this->db->query($query);
        $this->db->bind('id', $id);

        $this->db->execute();

        return $this->db->rowCount();
    }
    public function ubahDataguru($data)
    {
        $query = "UPDATE guru SET
        nama = :nama,
        mata_pelajaran = :mata_pelajaran,
        WHERE id = :id";

        $this->db->query($query);
        $this->db->bind('nama', $data['nama']);
        $this->db->bind('mata_pelajaran', $data['mata_pelajaran']);

        $this->db->bind('id', $data['id']);

        $this->db->execute();

        return $this->db->rowCount();
    }
}
